import { Injectable } from '@nestjs/common';

@Injectable()
export class MeasureService {


    async create() {
        
    }
}
